package cat.institut.dam.conversor

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class LongitudActivity : AppCompatActivity() {

    // enKm = quants quilòmetres val 1 unitat (la unitat base és el km)
    private enum class Unitat(val simbol: String, val enKm: Double) {
        QUILOMETRE("km", 1.0),
        MILLA("mi", 1.609344),
        YARDA("yd", 0.0009144)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_longitud)

        val editValor = findViewById<EditText>(R.id.editValor)
        val radioGroupDe = findViewById<RadioGroup>(R.id.radioGroupDe)
        val radioGroupA = findViewById<RadioGroup>(R.id.radioGroupA)
        val botoConvertir = findViewById<Button>(R.id.botoConvertir)
        val textResultat = findViewById<TextView>(R.id.textResultat)

        botoConvertir.setOnClickListener {
            val text = editValor.text.toString().trim()
            if (text.isEmpty()) {
                Toast.makeText(this, R.string.error_buid, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val valor = text.toDoubleOrNull()
            if (valor == null) {
                Toast.makeText(this, R.string.error_numeric, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val de = unitatOrigen(radioGroupDe.checkedRadioButtonId)
            val a = unitatDesti(radioGroupA.checkedRadioButtonId)
            if (de == null || a == null) {
                Toast.makeText(this, R.string.error_generic, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (de == a) {
                Toast.makeText(this, R.string.error_unitats, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            try {
                // origen -> km (multiplica) i km -> destí (divideix)
                val resultat = valor * de.enKm / a.enKm
                textResultat.text = String.format(Locale.US, "%.4f %s", resultat, a.simbol)
            } catch (e: Exception) {
                Toast.makeText(this, R.string.error_generic, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun unitatOrigen(id: Int): Unitat? = when (id) {
        R.id.radioQuilometre -> Unitat.QUILOMETRE
        R.id.radioMilla -> Unitat.MILLA
        R.id.radioYarda -> Unitat.YARDA
        else -> null
    }

    private fun unitatDesti(id: Int): Unitat? = when (id) {
        R.id.radioQuilometreA -> Unitat.QUILOMETRE
        R.id.radioMillaA -> Unitat.MILLA
        R.id.radioYardaA -> Unitat.YARDA
        else -> null
    }
}