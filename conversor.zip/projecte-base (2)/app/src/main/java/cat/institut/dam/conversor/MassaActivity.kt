package cat.institut.dam.conversor

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class MassaActivity : AppCompatActivity() {

    // enKg = quants quilograms val 1 unitat (la unitat base és el kg)
    private enum class Unitat(val simbol: String, val enKg: Double) {
        QUILOGRAM("kg", 1.0),
        LLIURA("lb", 0.45359237),
        UNCA("oz", 0.028349523125)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_massa)

        val editValor = findViewById<EditText>(R.id.editValor)
        val radioGroupDe = findViewById<RadioGroup>(R.id.radioGroupDe)
        val radioGroupA = findViewById<RadioGroup>(R.id.radioGroupA)
        val botoConvertir = findViewById<Button>(R.id.botoConvertir)
        val textResultat = findViewById<TextView>(R.id.textResultat)

        botoConvertir.setOnClickListener {
            val text = editValor.text.toString().trim()
            if (text.isEmpty()) {
                Toast.makeText(this, R.string.error_buid, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val valor = text.toDoubleOrNull()
            if (valor == null) {
                Toast.makeText(this, R.string.error_numeric, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val de = unitatOrigen(radioGroupDe.checkedRadioButtonId)
            val a = unitatDesti(radioGroupA.checkedRadioButtonId)
            if (de == null || a == null) {
                Toast.makeText(this, R.string.error_generic, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (de == a) {
                Toast.makeText(this, R.string.error_unitats, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            try {
                // origen -> kg (multiplica) i kg -> destí (divideix)
                val resultat = valor * de.enKg / a.enKg
                textResultat.text = String.format(Locale.US, "%.4f %s", resultat, a.simbol)
            } catch (e: Exception) {
                Toast.makeText(this, R.string.error_generic, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun unitatOrigen(id: Int): Unitat? = when (id) {
        R.id.radioQuilogram -> Unitat.QUILOGRAM
        R.id.radioLliura -> Unitat.LLIURA
        R.id.radioUnca -> Unitat.UNCA
        else -> null
    }

    private fun unitatDesti(id: Int): Unitat? = when (id) {
        R.id.radioQuilogramA -> Unitat.QUILOGRAM
        R.id.radioLliuraA -> Unitat.LLIURA
        R.id.radioUncaA -> Unitat.UNCA
        else -> null
    }
}