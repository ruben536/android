package cat.institut.dam.conversor

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class TemperaturaActivity : AppCompatActivity() {

    private enum class Unitat(val simbol: String) {
        CELSIUS("°C"), FAHRENHEIT("°F"), KELVIN("K")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_temperatura)

        val editValor = findViewById<EditText>(R.id.editValor)
        val radioGroupDe = findViewById<RadioGroup>(R.id.radioGroupDe)
        val radioGroupA = findViewById<RadioGroup>(R.id.radioGroupA)
        val botoConvertir = findViewById<Button>(R.id.botoConvertir)
        val textResultat = findViewById<TextView>(R.id.textResultat)

        botoConvertir.setOnClickListener {
            // 1) Llegir el valor
            val text = editValor.text.toString().trim()

            // 2) Validar que no és buit
            if (text.isEmpty()) {
                Toast.makeText(this, R.string.error_buid, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // 3) Validar que és un número
            val valor = text.toDoubleOrNull()
            if (valor == null) {
                Toast.makeText(this, R.string.error_numeric, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // 4) Llegir les unitats seleccionades
            val de = unitatOrigen(radioGroupDe.checkedRadioButtonId)
            val a = unitatDesti(radioGroupA.checkedRadioButtonId)
            if (de == null || a == null) {
                Toast.makeText(this, R.string.error_generic, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // 5) Comprovar que no són la mateixa unitat
            if (de == a) {
                Toast.makeText(this, R.string.error_unitats, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // 6) Calcular (passant per Celsius) i 7) mostrar
            try {
                val celsius = aCelsius(valor, de)
                val resultat = desdeCelsius(celsius, a)
                textResultat.text = String.format(Locale.US, "%.2f %s", resultat, a.simbol)
            } catch (e: Exception) {
                Toast.makeText(this, R.string.error_generic, Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Els ids d'origen i de destí són diferents, per això hi ha dues funcions
    private fun unitatOrigen(id: Int): Unitat? = when (id) {
        R.id.radioCelsius -> Unitat.CELSIUS
        R.id.radioFahrenheit -> Unitat.FAHRENHEIT
        R.id.radioKelvin -> Unitat.KELVIN
        else -> null
    }

    private fun unitatDesti(id: Int): Unitat? = when (id) {
        R.id.radioCelsiusA -> Unitat.CELSIUS
        R.id.radioFahrenheitA -> Unitat.FAHRENHEIT
        R.id.radioKelvinA -> Unitat.KELVIN
        else -> null
    }

    // Unitat d'origen -> unitat base (Celsius)
    private fun aCelsius(valor: Double, de: Unitat): Double = when (de) {
        Unitat.CELSIUS -> valor
        Unitat.FAHRENHEIT -> (valor - 32) * 5.0 / 9.0
        Unitat.KELVIN -> valor - 273.15
    }

    // Unitat base (Celsius) -> unitat de destí
    private fun desdeCelsius(celsius: Double, a: Unitat): Double = when (a) {
        Unitat.CELSIUS -> celsius
        Unitat.FAHRENHEIT -> celsius * 9.0 / 5.0 + 32
        Unitat.KELVIN -> celsius + 273.15
    }
}