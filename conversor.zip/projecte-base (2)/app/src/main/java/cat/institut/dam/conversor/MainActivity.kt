package cat.institut.dam.conversor

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import android.widget.Button

/**
 * MainActivity — Pantalla d'inici (menú) del Conversor.
 *
 * És l'Activity marcada amb MAIN / LAUNCHER a l'AndroidManifest.xml:
 * en arrencar l'aplicació, Android obre aquesta pantalla.
 *
 * ---------------------------------------------------------------------------
 * TASCA (Pràctica 1B)
 * ---------------------------------------------------------------------------
 * 1. Afegeix al layout `activity_main.xml` els tres botons del menú
 *    (temperatura, longitud i massa) amb els identificadors indicats
 *    a l'enunciat.
 * 2. associate cada botó amb el listener que obre la conversora
 *    corresponent mitjançant un INTENT EXPLÍCIT.
 *
 * Pista: un Intent explícit es crea amb
 *      Intent(this, ActivityDesti::class.java)
 * i s'engega amb
 *      startActivity(intent)
 */
class MainActivity : AppCompatActivity() {

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_main)

            val botoTemperatura = findViewById<Button>(R.id.botoTemperatura)

            botoTemperatura.setOnClickListener {
                val intent = Intent(this, TemperaturaActivity::class.java)
                startActivity(intent)
            }
            val botoLongitud = findViewById<Button>(R.id.botoLongitud)
            val botoMassa = findViewById<Button>(R.id.botoMassa)

            botoLongitud.setOnClickListener {
                startActivity(Intent(this, LongitudActivity::class.java))
            }

            botoMassa.setOnClickListener {
                startActivity(Intent(this, MassaActivity::class.java))
            }
        }
    }

