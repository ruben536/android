package cat.institut.dam.contactes

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * ContacteDetallActivity — la fitxa d'un contacte.
 *
 * Rep per l'Intent només l'id del contacte (EXTRA_ID) i busca la resta de
 * dades al ContactesRepository. Els sis botons obren altres aplicacions del
 * sistema amb Intent implícits.
 */
class ContacteDetallActivity : AppCompatActivity() {

    companion object {
        /** Clau de l'extra de l'Intent que porta l'id del contacte. */
        const val EXTRA_ID = "extra_id"

        private const val REQUEST_FOTO = 200
        private const val TAG = "Contactes"
    }

    private lateinit var contacte: Contacte
    private lateinit var ivFoto: ImageView

    /** Cua de missatges del fil principal (per tornar del fil de segon pla). */
    private val filPrincipal = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detall)
        Finestres.aplica(this, findViewById<View>(R.id.arrel))

        // 1. Recuperem l'id i busquem el contacte al repositori
        val id = intent.getIntExtra(EXTRA_ID, -1)
        val trobat = ContactesRepository.contacte(id)
        if (trobat == null) {
            Toast.makeText(this, R.string.error_contacte, Toast.LENGTH_LONG).show()
            finish()
            return
        }
        contacte = trobat

        // 2. Mostrem les dades
        ivFoto = findViewById(R.id.ivFoto)
        findViewById<TextView>(R.id.tvNom).text = contacte.nom
        findViewById<TextView>(R.id.tvEmail).text = contacte.email
        findViewById<TextView>(R.id.tvTelefon).text = contacte.telefon
        findViewById<TextView>(R.id.tvAdreca).text = contacte.adreçaCompleta
        findViewById<TextView>(R.id.tvWeb).text = contacte.web

        // Favorit: primer el valor, després el listener
        val chkFavorit = findViewById<CheckBox>(R.id.chkFavorit)
        chkFavorit.isChecked = ContactesRepository.esFavorit(contacte.id)
        chkFavorit.setOnCheckedChangeListener { _, _ ->
            ContactesRepository.alternaFavorit(contacte.id)
        }

        // 3. Foto: la de la galeria si n'hi ha; si no, la descarreguem de la xarxa
        val fotoTriada = ContactesRepository.foto(contacte.id)
        if (fotoTriada != null) {
            ivFoto.setImageURI(fotoTriada)
        } else {
            descarregaAvatar()
        }

        // 4. Els sis botons (Intent implícits)
        findViewById<Button>(R.id.btnTrucar).setOnClickListener { trucar() }
        findViewById<Button>(R.id.btnCorreu).setOnClickListener { escriuCorreu() }
        findViewById<Button>(R.id.btnMapa).setOnClickListener { obreMapa() }
        findViewById<Button>(R.id.btnWeb).setOnClickListener { obreWeb() }
        findViewById<Button>(R.id.btnAlarma).setOnClickListener { posaAlarma() }
        findViewById<Button>(R.id.btnGaleria).setOnClickListener { triaFoto() }
    }

    /** Baixa l'avatar en un fil de segon pla i el mostra quan arriba. */
    private fun descarregaAvatar() {
        Thread {
            val bitmap = ContactesService.baixaImatge(contacte.urlAvatar)
            filPrincipal.post {
                // Si no hi ha xarxa (bitmap null) es queda el dibuix per defecte.
                // Si mentrestant l'usuari ha triat una foto, no la trepitgem.
                if (bitmap != null && !isDestroyed &&
                    ContactesRepository.foto(contacte.id) == null
                ) {
                    ivFoto.setImageBitmap(bitmap)
                }
            }
        }.start()
    }

    /**
     * Llança un Intent implícit. Si no hi ha cap aplicació que el pugui
     * atendre, Android llença ActivityNotFoundException: l'agafem i avisem.
     */
    private fun obre(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.error_app_no_disponible, Toast.LENGTH_LONG).show()
        } catch (e: SecurityException) {
            Log.e(TAG, "Permís denegat en obrir l'Intent", e)
            Toast.makeText(this, R.string.error_app_no_disponible, Toast.LENGTH_LONG).show()
        }
    }

    /** Marcador de telèfon amb el número (esquema tel:). */
    private fun trucar() {
        obre(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${contacte.telefon}")))
    }

    /** Client de correu amb el destinatari posat (esquema mailto:). */
    private fun escriuCorreu() {
        obre(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:${contacte.email}")))
    }

    /** Mapa a la posició del contacte (esquema geo:), amb el nom com a etiqueta. */
    private fun obreMapa() {
        val etiqueta = Uri.encode(contacte.nom)
        val uri = Uri.parse(
            "geo:${contacte.latitud},${contacte.longitud}" +
                    "?q=${contacte.latitud},${contacte.longitud}($etiqueta)"
        )
        obre(Intent(Intent.ACTION_VIEW, uri))
    }

    /** Navegador amb la web del contacte. El servidor la dona sense https://. */
    private fun obreWeb() {
        var web = contacte.web
        if (!web.startsWith("http")) web = "https://$web"
        obre(Intent(Intent.ACTION_VIEW, Uri.parse(web)))
    }

    /** Aplicació d'alarmes amb una alarma a les 9:00 (no porta URI, porta extres). */
    private fun posaAlarma() {
        val alarma = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, 9)
            putExtra(AlarmClock.EXTRA_MINUTES, 0)
            putExtra(AlarmClock.EXTRA_MESSAGE, getString(R.string.alarma_missatge, contacte.nom))
        }
        obre(alarma)
    }

    /** Selector de documents del sistema, filtrat a imatges. */
    private fun triaFoto() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                        Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            )
        }
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(intent, REQUEST_FOTO)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.error_app_no_disponible, Toast.LENGTH_LONG).show()
        }
    }

    /** Resultat del selector: arriba una URI content://..., no un fitxer. */
    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_FOTO || resultCode != RESULT_OK) return
        val uri = data?.data ?: return

        try {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (e: SecurityException) {
            // alguns selectors no concedeixen un permís persistent
        }

        ContactesRepository.desaFoto(contacte.id, uri)
        ivFoto.setImageURI(uri)
    }
}