package cat.institut.dam.contactes

import android.net.Uri

/**
 * Repositori: guarda les dades compartides entre la llista i la fitxa.
 * És un object (singleton): només n'hi ha una còpia a tota l'aplicació.
 */
object ContactesRepository {

    private val contactes = mutableListOf<Contacte>()

    /** Ids dels contactes marcats com a favorits (un Set no té duplicats). */
    private val favorits = mutableSetOf<Int>()

    /** Foto triada per l'usuari a la galeria, per id de contacte. */
    private val fotos = mutableMapOf<Int, Uri>()

    /** La llista de contactes carregats (només lectura per a qui la consulta). */
    val llista: List<Contacte>
        get() = contactes

    /** Substitueix la llista actual per una de nova. */
    fun actualitza(novs: List<Contacte>) {
        contactes.clear()
        contactes.addAll(novs)
    }

    /** Busca un contacte pel seu id. Torna null si no el troba. */
    fun contacte(id: Int): Contacte? = contactes.firstOrNull { it.id == id }

    fun esFavorit(id: Int): Boolean = id in favorits

    /** Si era favorit el treu; si no ho era, l'afegeix. */
    fun alternaFavorit(id: Int) {
        if (!favorits.remove(id)) favorits.add(id)
    }

    /** Filtra pel nom, la ciutat o el correu. Amb text buit torna tots. */
    fun cerca(texte: String): List<Contacte> {
        val q = texte.trim()
        if (q.isEmpty()) return contactes.toList()
        return contactes.filter {
            it.nom.contains(q, ignoreCase = true) ||
                    it.ciutat.contains(q, ignoreCase = true) ||
                    it.email.contains(q, ignoreCase = true)
        }
    }

    /** Guarda la foto triada per a un contacte (només en memòria). */
    fun desaFoto(id: Int, uri: Uri) {
        fotos[id] = uri
    }

    /** La foto triada per a un contacte, o null si no n'hi ha. */
    fun foto(id: Int): Uri? = fotos[id]
}