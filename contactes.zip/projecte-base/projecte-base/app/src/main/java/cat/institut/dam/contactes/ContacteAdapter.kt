package cat.institut.dam.contactes

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/**
 * Adapter del RecyclerView: connecta la llista de contactes amb les files.
 *
 * No decideix què passa en prémer: avisa la Activity amb dos callbacks.
 *  - onContacteClick: s'ha premut la fila.
 *  - onFavoritClick: s'ha marcat o desmarcat la casella de favorit.
 */
class ContacteAdapter(
    private val onContacteClick: (Contacte) -> Unit,
    private val onFavoritClick: (Contacte) -> Unit
) : RecyclerView.Adapter<ContacteAdapter.ContacteViewHolder>() {

    private var contactes: List<Contacte> = emptyList()

    /** Canvia la llista que es mostra i repinta les files. */
    fun actualitza(novs: List<Contacte>) {
        contactes = novs
        notifyDataSetChanged()
    }

    /** Guarda les referències a les vistes d'una fila, per no buscar-les cada cop. */
    class ContacteViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvInicials: TextView = itemView.findViewById(R.id.tvInicials)
        val tvNom: TextView = itemView.findViewById(R.id.tvNom)
        val tvCiutat: TextView = itemView.findViewById(R.id.tvCiutat)
        val tvCorreu: TextView = itemView.findViewById(R.id.tvCorreu)
        val chkFavorit: CheckBox = itemView.findViewById(R.id.chkFavorit)
    }

    /** Crea la vista d'una fila (només quan cal; després es reciclen). */
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContacteViewHolder {
        val vista = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_contacte, parent, false)
        return ContacteViewHolder(vista)
    }

    /** Posa les dades del contacte de la posició indicada dins la fila. */
    override fun onBindViewHolder(holder: ContacteViewHolder, position: Int) {
        val contacte = contactes[position]

        holder.tvInicials.text = contacte.inicials
        holder.tvNom.text = contacte.nom
        holder.tvCiutat.text = contacte.ciutat
        holder.tvCorreu.text = contacte.email

        // Clic a la fila
        holder.itemView.setOnClickListener { onContacteClick(contacte) }

        // Favorit: primer treiem el listener, després posem el valor i
        // finalment tornem a posar el listener. Si no, en reciclar la vista
        // es dispararia el callback i es marcaria el contacte equivocat.
        holder.chkFavorit.setOnCheckedChangeListener(null)
        holder.chkFavorit.isChecked = ContactesRepository.esFavorit(contacte.id)
        holder.chkFavorit.setOnCheckedChangeListener { _, _ ->
            onFavoritClick(contacte)
        }
    }

    /** Quantes files hi ha. */
    override fun getItemCount(): Int = contactes.size
}