package cat.institut.dam.contactes

import org.json.JSONObject

/**
 * Model de dades: un contacte de l'agenda.
 * Ve del JSON (del servidor o de assets/contactes.json).
 */
data class Contacte(
    val id: Int,
    val nom: String,
    val username: String,
    val email: String,
    val telefon: String,
    val web: String,
    val carrer: String,
    val ciutat: String,
    val codiPostal: String,
    val latitud: Double,
    val longitud: Double
) {

    /** Inicials de fins a dues paraules del nom (per al cercle de la fila). */
    val inicials: String
        get() = nom.split(" ")
            .filter { it.isNotBlank() }
            .take(2)
            .map { it.first().uppercaseChar() }
            .joinToString("")

    /** Carrer, ciutat i codi postal en una sola línia. */
    val adreçaCompleta: String
        get() = "$carrer, $ciutat $codiPostal"

    /** Adreça de la imatge del contacte. */
    val urlAvatar: String
        get() = "https://i.pravatar.cc/300?u=$username"

    companion object {
        /** Converteix un JSONObject (un element de l'array) en un Contacte. */
        fun desDeJson(json: JSONObject): Contacte {
            val adreça = json.getJSONObject("address")
            val geo = adreça.getJSONObject("geo")
            return Contacte(
                id = json.getInt("id"),
                nom = json.getString("name"),
                username = json.getString("username"),
                email = json.getString("email"),
                telefon = json.getString("phone"),
                web = json.getString("website"),
                carrer = adreça.getString("street"),
                ciutat = adreça.getString("city"),
                codiPostal = adreça.getString("zipcode"),
                latitud = geo.optString("lat").toDoubleOrNull() ?: 0.0,
                longitud = geo.optString("lng").toDoubleOrNull() ?: 0.0
            )
        }
    }
}