package cat.institut.dam.contactes

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

/**
 * Notificació de "contactes carregats".
 *
 * Una notificació necessita:
 *  - un canal (Android 8+), que es crea una sola vegada;
 *  - el permís POST_NOTIFICATIONS (Android 13+), que s'ha de demanar a l'usuari;
 *  - una icona petita (setSmallIcon), sense la qual no es mostra.
 */
object Notificacions {

    private const val CANAL_ID = "contactes_carregats"
    private const val NOTIFICACIO_ID = 1

    /** Crea el canal. Si ja existeix, el sistema conserva la seva configuració. */
    private fun creaCanal(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val canal = NotificationChannel(
                CANAL_ID,
                context.getString(R.string.canal_notificacions),
                NotificationManager.IMPORTANCE_DEFAULT
            )
            context.getSystemService(NotificationManager::class.java)
                .createNotificationChannel(canal)
        }
    }

    /**
     * Mostra la notificació amb el nombre de contactes carregats.
     * Si l'usuari ha denegat el permís (o té les notificacions desactivades)
     * no fa res: l'app ha de continuar funcionant igual.
     */
    @SuppressLint("MissingPermission") // ja comprovem areNotificationsEnabled()
    fun mostra(context: Context, quantitat: Int) {
        val gestor = NotificationManagerCompat.from(context)
        if (!gestor.areNotificationsEnabled()) return

        creaCanal(context)

        val notificacio = NotificationCompat.Builder(context, CANAL_ID)
            .setSmallIcon(R.drawable.ic_notificacio)
            .setContentTitle(context.getString(R.string.notificacio_titol))
            .setContentText(context.getString(R.string.notificacio_text, quantitat))
            .setAutoCancel(true)
            .build()

        gestor.notify(NOTIFICACIO_ID, notificacio)
    }
}