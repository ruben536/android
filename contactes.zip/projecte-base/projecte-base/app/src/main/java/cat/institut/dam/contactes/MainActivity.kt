package cat.institut.dam.contactes

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/**
 * MainActivity — la llista de contactes.
 *
 * Carrega els contactes (xarxa o còpia local), els filtra amb el cercador,
 * obre la fitxa en prémer una fila i mostra una notificació en acabar la càrrega.
 */
class MainActivity : AppCompatActivity() {

    companion object {
        /** Codi de la petició de permís de notificacions. */
        private const val REQUEST_NOTIFICACIONS = 100
        private const val TAG = "Contactes"
    }

    private lateinit var etCerca: EditText
    private lateinit var btnActualitza: Button
    private lateinit var pbCarga: ProgressBar
    private lateinit var txtBuit: TextView
    private lateinit var txtAvis: TextView
    private lateinit var rvContactes: RecyclerView
    private lateinit var adapter: ContacteAdapter

    /** Cua de missatges del fil principal: permet tornar-hi des d'un fil de segon pla. */
    private val filPrincipal = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Finestres.aplica(this, findViewById<View>(R.id.arrel))

        etCerca = findViewById(R.id.etCerca)
        btnActualitza = findViewById(R.id.btnActualitza)
        pbCarga = findViewById(R.id.pbCarga)
        txtBuit = findViewById(R.id.txtBuit)
        txtAvis = findViewById(R.id.txtAvis)
        rvContactes = findViewById(R.id.rvContactes)

        // TODO 1: adapter + RecyclerView
        adapter = ContacteAdapter(
            onContacteClick = { contacte ->
                // Intent explícit: només passem l'id; la fitxa busca el contacte al repositori
                val intent = Intent(this, ContacteDetallActivity::class.java)
                intent.putExtra(ContacteDetallActivity.EXTRA_ID, contacte.id)
                startActivity(intent)
            },
            onFavoritClick = { contacte ->
                ContactesRepository.alternaFavorit(contacte.id)
            }
        )
        rvContactes.layoutManager = LinearLayoutManager(this)
        rvContactes.adapter = adapter

        // TODO 2: el cercador filtra la llista a cada tecla
        etCerca.doAfterTextChanged {
            mostraLlista()
        }

        // TODO 3: el botó torna a carregar els contactes
        btnActualitza.setOnClickListener {
            carrega()
        }

        // TODO 4: la càrrega demana el permís de notificacions quan acaba (veure carrega())
        carrega()
    }

    /** En tornar de la fitxa, repinta la llista (per veure el favorit canviat). */
    override fun onResume() {
        super.onResume()
        if (ContactesRepository.llista.isNotEmpty()) mostraLlista()
    }

    /**
     * Pinta a la llista els contactes que coincideixen amb el text del cercador.
     * Amb el cercador buit es mostren tots. Si no n'hi ha cap, es mostra el
     * missatge corresponent.
     */
    private fun mostraLlista() {
        val text = etCerca.text.toString()
        val filtrats = ContactesRepository.cerca(text)
        adapter.actualitza(filtrats)

        if (filtrats.isEmpty()) {
            txtBuit.setText(
                if (text.isBlank()) R.string.txt_buit else R.string.txt_buit_cerca
            )
            txtBuit.visibility = View.VISIBLE
        } else {
            txtBuit.visibility = View.GONE
        }
    }

    /**
     * TODO 5: carrega els contactes.
     *
     * La feina lenta (HTTP) es fa en un fil de segon pla. El resultat torna al
     * fil principal amb el Handler per actualitzar la interfície.
     * Si la xarxa falla, es carrega la còpia local (assets/contactes.json)
     * i es mostra l'avís taronja.
     */
    private fun carrega() {
        pbCarga.visibility = View.VISIBLE
        txtAvis.visibility = View.GONE
        btnActualitza.isEnabled = false

        Thread {
            // Fil de segon pla: aquí NO es toca la interfície
            val deXarxa = try {
                ContactesService.desDeXarxa()
            } catch (e: Exception) {
                Log.w(TAG, "No s'ha pogut carregar de la xarxa: ${e.message}")
                null
            }
            val contactes = deXarxa ?: try {
                ContactesService.desDeRecurs(this)
            } catch (e: Exception) {
                Log.e(TAG, "No s'ha pogut carregar la còpia local", e)
                null
            }
            val local = deXarxa == null

            // Tornem al fil principal per actualitzar la interfície
            filPrincipal.post {
                if (isFinishing || isDestroyed) return@post

                pbCarga.visibility = View.GONE
                btnActualitza.isEnabled = true

                if (contactes == null) {
                    Toast.makeText(this, R.string.error_carrega, Toast.LENGTH_LONG).show()
                    mostraLlista()
                } else {
                    ContactesRepository.actualitza(contactes)
                    if (local) {
                        txtAvis.setText(R.string.avis_dades_locals)
                        txtAvis.visibility = View.VISIBLE
                    }
                    mostraLlista()
                    notificaCarrega()
                }
            }
        }.start()
    }

    /** Hi ha permís per mostrar notificacions? (abans d'Android 13 no cal) */
    private fun tePermisNotificacions(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true
        return ContextCompat.checkSelfPermission(
            this, Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * TODO 4: després de carregar, si ja tenim permís mostrem la notificació;
     * si no, el demanem (la notificació es mostrarà quan l'usuari el concedeixi).
     */
    private fun notificaCarrega() {
        if (tePermisNotificacions()) {
            Notificacions.mostra(this, ContactesRepository.llista.size)
        } else {
            demanaPermisNotificacions()
        }
    }

    /**
     * A partir d'Android 13 (API 33) cal demanar permís en temps d'execució
     * per poder mostrar notificacions. En versions anteriors el permís no
     * existeix i no cal demanar-lo.
     */
    private fun demanaPermisNotificacions() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
        val permissio = Manifest.permission.POST_NOTIFICATIONS
        if (ContextCompat.checkSelfPermission(this, permissio) == PackageManager.PERMISSION_GRANTED) {
            return
        }
        requestPermissions(arrayOf(permissio), REQUEST_NOTIFICACIONS)
    }

    /**
     * Resposta de l'usuari a la petició de permís: si el concedeix, mostrem la
     * notificació; si el denega, l'avisem amb un Toast i l'app continua igual.
     */
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_NOTIFICACIONS) {
            val concedit = grantResults.isNotEmpty() &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED
            if (concedit) {
                Notificacions.mostra(this, ContactesRepository.llista.size)
            } else {
                // TODO 6: avisa l'usuari que no es mostraran notificacions
                Toast.makeText(this, R.string.permis_denegada, Toast.LENGTH_LONG).show()
            }
        }
    }
}