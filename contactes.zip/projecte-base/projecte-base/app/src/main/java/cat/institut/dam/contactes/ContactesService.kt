package cat.institut.dam.contactes

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

/**
 * Servei de dades: d'on surten els contactes (xarxa o còpia local)
 * i com es baixen les imatges.
 *
 * IMPORTANT: aquestes funcions fan feina lenta (xarxa, disc).
 * Cal cridar-les des d'un fil de segon pla, MAI des del fil principal.
 */
object ContactesService {

    const val URL_CONTACTES = "https://jsonplaceholder.typicode.com/users"

    private const val TIMEOUT_MS = 8000

    /**
     * Fa la petició HTTP al servidor i torna la llista de contactes.
     * Llança una excepció si no hi ha xarxa o el servidor no respon amb 200.
     */
    fun desDeXarxa(): List<Contacte> {
        val connexio = URL(URL_CONTACTES).openConnection() as HttpURLConnection
        try {
            connexio.requestMethod = "GET"
            connexio.connectTimeout = TIMEOUT_MS
            connexio.readTimeout = TIMEOUT_MS
            if (connexio.responseCode != HttpURLConnection.HTTP_OK) {
                throw IllegalStateException(
                    "El servidor ha respost amb ${connexio.responseCode}"
                )
            }
            val text = connexio.inputStream.bufferedReader().use { it.readText() }
            return parseja(text)
        } finally {
            connexio.disconnect()
        }
    }

    /** Llegeix la còpia local assets/contactes.json i torna els contactes. */
    fun desDeRecurs(context: Context): List<Contacte> {
        val text = context.assets.open("contactes.json")
            .bufferedReader()
            .use { it.readText() }
        return parseja(text)
    }

    /** Converteix el text JSON (un array d'objectes) en una llista de Contacte. */
    fun parseja(text: String): List<Contacte> {
        val array = JSONArray(text)
        val resultat = mutableListOf<Contacte>()
        for (i in 0 until array.length()) {
            resultat.add(Contacte.desDeJson(array.getJSONObject(i)))
        }
        return resultat
    }

    /** Baixa una imatge de la xarxa. Torna null si alguna cosa falla. */
    fun baixaImatge(url: String): Bitmap? {
        return try {
            val connexio = URL(url).openConnection() as HttpURLConnection
            try {
                connexio.connectTimeout = TIMEOUT_MS
                connexio.readTimeout = TIMEOUT_MS
                BitmapFactory.decodeStream(connexio.inputStream)
            } finally {
                connexio.disconnect()
            }
        } catch (e: Exception) {
            null
        }
    }
}